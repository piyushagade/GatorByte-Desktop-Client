from serial.tools.list_ports import comports

print(comports())